"""
aspen.algorithms
++++++++++++++++

Contains algorithm definitions per the algorithm module.
"""
