
# for backwards compatibility with aspen-renderer modules
from .simplates.renderers import Factory, Renderer

Factory, Renderer # make pyflakes happy
